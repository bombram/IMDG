#include "dataloader.h"

DataLoader::DataLoader()
{

}
