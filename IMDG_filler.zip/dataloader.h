#ifndef DATALOADER_H
#define DATALOADER_H
#include <QObject>

class DataLoader
{
    Q_OBJECT
public:

    DataLoader();

};

#endif // DATALOADER_H
